-- =========================================
-- SCRIPT 01 - CREACION DE ESQUEMA Y OBJETOS
-- Base de datos: idea_martinez
-- =========================================

DROP DATABASE IF EXISTS idea_martinez;
CREATE DATABASE idea_martinez
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;

USE idea_martinez;

-- =========================
-- TABLA: cliente
-- =========================
CREATE TABLE cliente (
    id_cliente INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    apellido VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    telefono VARCHAR(50),
    id_direccion INT,
    fecha_alta DATE,
    activo TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

-- =========================
-- TABLA: direccion
-- =========================
CREATE TABLE direccion (
    id_direccion INT AUTO_INCREMENT PRIMARY KEY,
    calle VARCHAR(150) NOT NULL,
    numero VARCHAR(10),
    ciudad VARCHAR(100),
    provincia VARCHAR(100),
    codigo_postal VARCHAR(20)
) ENGINE=InnoDB;

-- =========================
-- TABLA: categoria_producto
-- =========================
CREATE TABLE categoria_producto (
    id_categoria INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    descripcion VARCHAR(255)
) ENGINE=InnoDB;

-- =========================
-- TABLA: proveedor
-- =========================
CREATE TABLE proveedor (
    id_proveedor INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(150) NOT NULL,
    email VARCHAR(150),
    telefono VARCHAR(50)
) ENGINE=InnoDB;

-- =========================
-- TABLA: producto
-- =========================
CREATE TABLE producto (
    id_producto INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(150) NOT NULL,
    descripcion VARCHAR(255),
    precio_lista DECIMAL(10,2) NOT NULL,
    id_categoria INT NOT NULL,
    id_proveedor INT,
    activo TINYINT(1) NOT NULL DEFAULT 1,
    FOREIGN KEY (id_categoria) REFERENCES categoria_producto(id_categoria),
    FOREIGN KEY (id_proveedor) REFERENCES proveedor(id_proveedor)
) ENGINE=InnoDB;

-- =========================
-- TABLA: inventario
-- =========================
CREATE TABLE inventario (
    id_inventario INT AUTO_INCREMENT PRIMARY KEY,
    id_producto INT NOT NULL,
    stock_actual INT NOT NULL,
    stock_minimo INT NOT NULL,
    FOREIGN KEY (id_producto) REFERENCES producto(id_producto)
) ENGINE=InnoDB;

-- =========================
-- TABLA: estado_pedido
-- =========================
CREATE TABLE estado_pedido (
    id_estado_pedido INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL
) ENGINE=InnoDB;

-- =========================
-- TABLA TRANSACCIONAL 1: pedido
-- =========================
CREATE TABLE pedido (
    id_pedido INT AUTO_INCREMENT PRIMARY KEY,
    id_cliente INT NOT NULL,
    fecha_pedido DATETIME NOT NULL,
    id_estado_pedido INT NOT NULL,
    observaciones VARCHAR(255),
    FOREIGN KEY (id_cliente) REFERENCES cliente(id_cliente),
    FOREIGN KEY (id_estado_pedido) REFERENCES estado_pedido(id_estado_pedido)
) ENGINE=InnoDB;

-- =========================
-- TABLA: detalle_pedido
-- =========================
CREATE TABLE detalle_pedido (
    id_detalle_pedido INT AUTO_INCREMENT PRIMARY KEY,
    id_pedido INT NOT NULL,
    id_producto INT NOT NULL,
    cantidad INT NOT NULL,
    precio_unitario DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (id_pedido) REFERENCES pedido(id_pedido),
    FOREIGN KEY (id_producto) REFERENCES producto(id_producto)
) ENGINE=InnoDB;

-- =========================
-- TABLA: metodo_pago
-- =========================
CREATE TABLE metodo_pago (
    id_metodo_pago INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL
) ENGINE=InnoDB;

-- =========================
-- TABLA TRANSACCIONAL 2: factura
-- =========================
CREATE TABLE factura (
    id_factura INT AUTO_INCREMENT PRIMARY KEY,
    id_pedido INT NOT NULL,
    fecha_factura DATETIME NOT NULL,
    total_factura DECIMAL(12,2),
    id_metodo_pago INT NOT NULL,
    FOREIGN KEY (id_pedido) REFERENCES pedido(id_pedido),
    FOREIGN KEY (id_metodo_pago) REFERENCES metodo_pago(id_metodo_pago)
) ENGINE=InnoDB;

-- =========================
-- TABLA DE HECHOS: fact_venta
-- =========================
CREATE TABLE fact_venta (
    id_fact_venta INT AUTO_INCREMENT PRIMARY KEY,
    id_factura INT NOT NULL,
    id_producto INT NOT NULL,
    cantidad INT NOT NULL,
    precio_unitario DECIMAL(10,2) NOT NULL,
    subtotal DECIMAL(12,2) NOT NULL,
    FOREIGN KEY (id_factura) REFERENCES factura(id_factura),
    FOREIGN KEY (id_producto) REFERENCES producto(id_producto)
) ENGINE=InnoDB;

-- =========================
-- TABLA: pago
-- =========================
CREATE TABLE pago (
    id_pago INT AUTO_INCREMENT PRIMARY KEY,
    id_factura INT NOT NULL,
    fecha_pago DATETIME NOT NULL,
    monto_pago DECIMAL(12,2) NOT NULL,
    FOREIGN KEY (id_factura) REFERENCES factura(id_factura)
) ENGINE=InnoDB;

-- =========================
-- TABLA: envio
-- =========================
CREATE TABLE envio (
    id_envio INT AUTO_INCREMENT PRIMARY KEY,
    id_pedido INT NOT NULL,
    direccion_envio VARCHAR(255) NOT NULL,
    fecha_envio DATETIME,
    costo_envio DECIMAL(10,2),
    empresa_envio VARCHAR(100),
    codigo_seguimiento VARCHAR(100),
    FOREIGN KEY (id_pedido) REFERENCES pedido(id_pedido)
) ENGINE=InnoDB;

-- =========================
-- TABLA: usuario
-- =========================
CREATE TABLE usuario (
    id_usuario INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    email VARCHAR(150) NOT NULL,
    rol VARCHAR(50) NOT NULL,
    fecha_creacion DATETIME NOT NULL,
    activo TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

-- =========================
-- TABLA: auditoria_stock
-- =========================
CREATE TABLE auditoria_stock (
    id_auditoria INT AUTO_INCREMENT PRIMARY KEY,
    id_producto INT NOT NULL,
    fecha_cambio DATETIME NOT NULL,
    stock_anterior INT NOT NULL,
    stock_nuevo INT NOT NULL,
    motivo VARCHAR(255),
    FOREIGN KEY (id_producto) REFERENCES producto(id_producto)
) ENGINE=InnoDB;

-- =========================================================
-- VISTAS (5 o mas)
-- =========================================================

-- 1) Ventas totales por cliente
CREATE VIEW vw_ventas_por_cliente AS
SELECT 
    c.id_cliente,
    c.nombre,
    c.apellido,
    SUM(fv.subtotal) AS total_ventas
FROM fact_venta fv
JOIN factura fa ON fv.id_factura = fa.id_factura
JOIN pedido p ON fa.id_pedido = p.id_pedido
JOIN cliente c ON p.id_cliente = c.id_cliente
GROUP BY c.id_cliente, c.nombre, c.apellido;

-- 2) Ventas por categoria de producto
CREATE VIEW vw_ventas_por_categoria AS
SELECT 
    cp.id_categoria,
    cp.nombre AS categoria,
    SUM(fv.subtotal) AS total_categoria
FROM fact_venta fv
JOIN producto pr ON fv.id_producto = pr.id_producto
JOIN categoria_producto cp ON pr.id_categoria = cp.id_categoria
GROUP BY cp.id_categoria, cp.nombre;

-- 3) Stock bajo
CREATE VIEW vw_stock_bajo AS
SELECT 
    pr.id_producto,
    pr.nombre,
    i.stock_actual,
    i.stock_minimo
FROM inventario i
JOIN producto pr ON i.id_producto = pr.id_producto
WHERE i.stock_actual <= i.stock_minimo;

-- 4) Pedidos pendientes de envio
CREATE VIEW vw_pedidos_pendientes_envio AS
SELECT 
    p.id_pedido,
    c.nombre,
    c.apellido,
    p.fecha_pedido,
    ep.nombre AS estado
FROM pedido p
JOIN cliente c ON p.id_cliente = c.id_cliente
JOIN estado_pedido ep ON p.id_estado_pedido = ep.id_estado_pedido
LEFT JOIN envio e ON p.id_pedido = e.id_pedido
WHERE e.id_envio IS NULL;

-- 5) Detalle de factura con cliente y producto
CREATE VIEW vw_detalle_factura_completo AS
SELECT 
    fa.id_factura,
    fa.fecha_factura,
    c.nombre AS nombre_cliente,
    c.apellido AS apellido_cliente,
    pr.nombre AS nombre_producto,
    fv.cantidad,
    fv.precio_unitario,
    fv.subtotal
FROM fact_venta fv
JOIN factura fa ON fv.id_factura = fa.id_factura
JOIN pedido p ON fa.id_pedido = p.id_pedido
JOIN cliente c ON p.id_cliente = c.id_cliente
JOIN producto pr ON fv.id_producto = pr.id_producto;

-- =========================================================
-- FUNCIONES (2 o mas)
-- =========================================================

DELIMITER $$

-- 1) Funcion: nombre completo de cliente
CREATE FUNCTION fn_cliente_fullname(p_id_cliente INT)
RETURNS VARCHAR(255)
DETERMINISTIC
BEGIN
    DECLARE v_fullname VARCHAR(255);
    SELECT CONCAT(nombre, ' ', apellido)
    INTO v_fullname
    FROM cliente
    WHERE id_cliente = p_id_cliente;

    RETURN v_fullname;
END $$

-- 2) Funcion: calcula total de una factura
CREATE FUNCTION fn_total_factura(p_id_factura INT)
RETURNS DECIMAL(12,2)
DETERMINISTIC
BEGIN
    DECLARE v_total DECIMAL(12,2);
    SELECT IFNULL(SUM(subtotal),0)
    INTO v_total
    FROM fact_venta
    WHERE id_factura = p_id_factura;

    RETURN v_total;
END $$

DELIMITER ;

-- =========================================================
-- STORED PROCEDURES (2 o mas)
-- =========================================================

DELIMITER $$

-- 1) SP para crear un pedido simple (un solo producto)
CREATE PROCEDURE sp_crear_pedido_simple(
    IN p_id_cliente INT,
    IN p_id_producto INT,
    IN p_cantidad INT,
    IN p_precio_unitario DECIMAL(10,2),
    IN p_id_metodo_pago INT
)
BEGIN
    DECLARE v_id_pedido INT;
    DECLARE v_id_factura INT;
    DECLARE v_subtotal DECIMAL(12,2);

    SET v_subtotal = p_cantidad * p_precio_unitario;

    -- Crear pedido
    INSERT INTO pedido (id_cliente, fecha_pedido, id_estado_pedido, observaciones)
    VALUES (p_id_cliente, NOW(), 1, 'Pedido creado desde SP');

    SET v_id_pedido = LAST_INSERT_ID();

    -- Detalle del pedido
    INSERT INTO detalle_pedido (id_pedido, id_producto, cantidad, precio_unitario)
    VALUES (v_id_pedido, p_id_producto, p_cantidad, p_precio_unitario);

    -- Crear factura
    INSERT INTO factura (id_pedido, fecha_factura, total_factura, id_metodo_pago)
    VALUES (v_id_pedido, NOW(), v_subtotal, p_id_metodo_pago);

    SET v_id_factura = LAST_INSERT_ID();

    -- Insertar en fact_venta (tabla de hechos)
    INSERT INTO fact_venta (id_factura, id_producto, cantidad, precio_unitario, subtotal)
    VALUES (v_id_factura, p_id_producto, p_cantidad, p_precio_unitario, v_subtotal);
END $$

-- 2) SP para registrar un pago
CREATE PROCEDURE sp_registrar_pago_factura(
    IN p_id_factura INT,
    IN p_monto DECIMAL(12,2)
)
BEGIN
    INSERT INTO pago (id_factura, fecha_pago, monto_pago)
    VALUES (p_id_factura, NOW(), p_monto);
END $$

DELIMITER ;

-- =========================================================
-- TRIGGERS (2 o mas)
-- =========================================================

DELIMITER $$

-- 1) Trigger: setear fecha_alta de cliente antes de insertar
CREATE TRIGGER trg_cliente_before_insert
BEFORE INSERT ON cliente
FOR EACH ROW
BEGIN
    IF NEW.fecha_alta IS NULL THEN
        SET NEW.fecha_alta = CURDATE();
    END IF;
END $$

-- 2) Trigger: actualizar stock e insertar auditoria al registrar venta
CREATE TRIGGER trg_fact_venta_after_insert
AFTER INSERT ON fact_venta
FOR EACH ROW
BEGIN
    DECLARE v_stock_anterior INT;

    SELECT stock_actual
    INTO v_stock_anterior
    FROM inventario
    WHERE id_producto = NEW.id_producto;

    UPDATE inventario
    SET stock_actual = stock_actual - NEW.cantidad
    WHERE id_producto = NEW.id_producto;

    INSERT INTO auditoria_stock (
        id_producto,
        fecha_cambio,
        stock_anterior,
        stock_nuevo,
        motivo
    ) VALUES (
        NEW.id_producto,
        NOW(),
        v_stock_anterior,
        v_stock_anterior - NEW.cantidad,
        'Venta registrada'
    );
END $$

DELIMITER ;

-- FIN SCRIPT 01
