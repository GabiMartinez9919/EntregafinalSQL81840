USE idea_martinez;

-- =========================
-- INSERTS: direccion
-- =========================
INSERT INTO direccion (calle, numero, ciudad, provincia, codigo_postal) VALUES
('San Martin', '1234', 'Buenos Aires', 'Buenos Aires', '1000'),
('Belgrano', '567', 'Lanus', 'Buenos Aires', '1824'),
('Mitre', '890', 'Avellaneda', 'Buenos Aires', '1870'),
('Rivadavia', '345', 'Lomas', 'Buenos Aires', '1832'),
('Sarmiento', '222', 'Quilmes', 'Buenos Aires', '1878');

-- =========================
-- INSERTS: cliente
-- =========================
INSERT INTO cliente (nombre, apellido, email, telefono, id_direccion, fecha_alta, activo) VALUES
('Juan', 'Perez', 'juan.perez@mail.com', '1111111111', 1, '2024-01-10', 1),
('Maria', 'Gomez', 'maria.gomez@mail.com', '2222222222', 2, '2024-02-05', 1),
('Carlos', 'Lopez', 'carlos.lopez@mail.com', '3333333333', 3, '2024-03-01', 1),
('Ana', 'Diaz', 'ana.diaz@mail.com', '4444444444', 4, '2024-03-15', 1),
('Luis', 'Torres', 'luis.torres@mail.com', '5555555555', 5, '2024-04-01', 1);

-- =========================
-- INSERTS: categoria_producto
-- =========================
INSERT INTO categoria_producto (nombre, descripcion) VALUES
('Tecnologia', 'Productos de tecnologia'),
('Hogar', 'Articulos para el hogar'),
('Gaming', 'Productos para gaming'),
('Oficina', 'Articulos de oficina'),
('Accesorios', 'Accesorios varios');

-- =========================
-- INSERTS: proveedor
-- =========================
INSERT INTO proveedor (nombre, email, telefono) VALUES
('Proveedor Uno', 'contacto1@proveedor.com', '1111111111'),
('Proveedor Dos', 'contacto2@proveedor.com', '2222222222'),
('Proveedor Tres', 'contacto3@proveedor.com', '3333333333');

-- =========================
-- INSERTS: producto
-- =========================
INSERT INTO producto (nombre, descripcion, precio_lista, id_categoria, id_proveedor, activo) VALUES
('Notebook Gamer', 'Notebook 15 pulgadas', 350000.00, 3, 1, 1),
('Mouse Gamer', 'Mouse optico', 15000.00, 3, 1, 1),
('Teclado Mecanico', 'Teclado mecanico', 30000.00, 3, 2, 1),
('Monitor 27', 'Monitor full hd', 180000.00, 1, 2, 1),
('Silla Gamer', 'Silla ergonomica', 250000.00, 3, 3, 1),
('Escritorio', 'Escritorio de oficina', 80000.00, 2, 3, 1),
('Auriculares', 'Auriculares inalambricos', 40000.00, 5, 1, 1),
('Impresora', 'Impresora multifuncion', 90000.00, 4, 2, 1);

-- =========================
-- INSERTS: inventario
-- =========================
INSERT INTO inventario (id_producto, stock_actual, stock_minimo) VALUES
(1, 20, 5),
(2, 50, 10),
(3, 35, 5),
(4, 15, 3),
(5, 10, 2),
(6, 25, 5),
(7, 40, 8),
(8, 12, 3);

-- =========================
-- INSERTS: estado_pedido
-- =========================
INSERT INTO estado_pedido (nombre) VALUES
('Pendiente'),
('Preparacion'),
('Enviado'),
('Entregado'),
('Cancelado');

-- =========================
-- INSERTS: metodo_pago
-- =========================
INSERT INTO metodo_pago (nombre) VALUES
('Tarjeta credito'),
('Tarjeta debito'),
('Transferencia'),
('Efectivo');

-- =========================
-- INSERTS: usuario
-- =========================
INSERT INTO usuario (username, email, rol, fecha_creacion, activo) VALUES
('admin', 'admin@idea.com', 'Admin', NOW(), 1),
('operador1', 'operador1@idea.com', 'Operador', NOW(), 1);

-- =========================
-- INSERTS: pedidos, facturas, ventas, pagos, envios
-- Generamos algunos pedidos con su flujo completo

-- Pedido 1 - cliente 1
INSERT INTO pedido (id_cliente, fecha_pedido, id_estado_pedido, observaciones)
VALUES (1, '2024-05-01 10:00:00', 4, 'Pedido completado');

INSERT INTO detalle_pedido (id_pedido, id_producto, cantidad, precio_unitario) VALUES
(LAST_INSERT_ID(), 1, 1, 350000.00),
(LAST_INSERT_ID(), 2, 2, 15000.00);

-- Factura 1 asociada al pedido 1
INSERT INTO factura (id_pedido, fecha_factura, total_factura, id_metodo_pago)
VALUES (1, '2024-05-01 10:05:00', 380000.00, 1);

-- Ventas (tabla de hechos) para factura 1
INSERT INTO fact_venta (id_factura, id_producto, cantidad, precio_unitario, subtotal) VALUES
(1, 1, 1, 350000.00, 350000.00),
(1, 2, 2, 15000.00, 30000.00);

-- Pago para factura 1
INSERT INTO pago (id_factura, fecha_pago, monto_pago)
VALUES (1, '2024-05-01 10:10:00', 380000.00);

-- Envio para pedido 1
INSERT INTO envio (id_pedido, direccion_envio, fecha_envio, costo_envio, empresa_envio, codigo_seguimiento)
VALUES (1, 'San Martin 1234, Buenos Aires', '2024-05-02 09:00:00', 3000.00, 'Correo Uno', 'SEG123456');

-- -----------------------------------------
-- Pedido 2 - cliente 2
-- -----------------------------------------
INSERT INTO pedido (id_cliente, fecha_pedido, id_estado_pedido, observaciones)
VALUES (2, '2024-05-03 15:30:00', 3, 'Envio en camino');

INSERT INTO detalle_pedido (id_pedido, id_producto, cantidad, precio_unitario) VALUES
(2, 3, 1, 30000.00),
(2, 7, 1, 40000.00);

INSERT INTO factura (id_pedido, fecha_factura, total_factura, id_metodo_pago)
VALUES (2, '2024-05-03 15:35:00', 70000.00, 2);

INSERT INTO fact_venta (id_factura, id_producto, cantidad, precio_unitario, subtotal) VALUES
(2, 3, 1, 30000.00, 30000.00),
(2, 7, 1, 40000.00, 40000.00);

INSERT INTO pago (id_factura, fecha_pago, monto_pago)
VALUES (2, '2024-05-04 10:00:00', 70000.00);

INSERT INTO envio (id_pedido, direccion_envio, fecha_envio, costo_envio, empresa_envio, codigo_seguimiento)
VALUES (2, 'Belgrano 567, Lanus', '2024-05-04 08:00:00', 2500.00, 'Correo Dos', 'SEG654321');

-- -----------------------------------------
-- Pedido 3 - cliente 3 (pendiente, sin factura aun)
-- -----------------------------------------
INSERT INTO pedido (id_cliente, fecha_pedido, id_estado_pedido, observaciones)
VALUES (3, '2024-05-05 11:20:00', 1, 'Pedido pendiente de pago');

INSERT INTO detalle_pedido (id_pedido, id_producto, cantidad, precio_unitario) VALUES
(3, 4, 1, 180000.00),
(3, 6, 1, 80000.00);

-- Puedes seguir agregando mas pedidos, facturas y ventas
-- para que el volumen de datos sea mayor.

-- FIN SCRIPT 02
